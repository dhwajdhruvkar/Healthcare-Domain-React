To run use : npm run dev
Then click on the localhost url
