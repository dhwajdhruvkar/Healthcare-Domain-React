import React from 'react';
import { useDropzone } from 'react-dropzone';

const FileUploader = ({ onFileUpload }) => {
  const { getRootProps, getInputProps } = useDropzone({
    onDrop: onFileUpload,
    accept: { 'application/pdf': ['.pdf'] },
    maxFiles: 1,
  });

  return (
    <div
      {...getRootProps()}
      className="w-full p-4 border-2 border-dashed rounded-md cursor-pointer text-gray-500"
    >
      <input {...getInputProps()} />
      <p>Drag & drop a file here, or click to select one</p>
    </div>
  );
};

export default FileUploader;
