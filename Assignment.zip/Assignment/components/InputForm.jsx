import React from 'react';

const InputForm = ({ register, errors }) => {
  return (
    <div className="space-y-4">
      <div>
        <label className="block font-semibold text-gray-700">Name:</label>
        <input
          {...register('name', { required: 'Name is required' })}
          type="text"
          className="w-full p-2 border rounded-md"
        />
        {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
      </div>
      <div>
        <label className="block font-semibold text-gray-700">Age:</label>
        <input
          {...register('age', {
            required: 'Age is required',
            valueAsNumber: true,
            validate: value => value > 0 || 'Enter a valid age',
          })}
          type="number"
          className="w-full p-2 border rounded-md"
        />
        {errors.age && <p className="text-red-500 text-sm">{errors.age.message}</p>}
      </div>
    </div>
  );
};

export default InputForm;
