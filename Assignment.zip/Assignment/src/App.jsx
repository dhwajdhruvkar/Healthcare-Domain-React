import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import InputForm from '/Web Development 2.0/Projects/Assignment/components/InputForm.jsx'
import FileUploader from '/Web Development 2.0/Projects/Assignment/components/FileUploader.jsx';

const App = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [file, setFile] = React.useState(null);

  const onSubmit = data => {
    console.log('Submitted Data:', { ...data, file });
    alert('Form submitted successfully!');
  };

  const handleFileUpload = files => {
    setFile(files[0]);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center">
      {/* Background */}
      <div className="absolute top-0 z-[-2] h-screen w-screen bg-white bg-[radial-gradient(100%_50%_at_50%_0%,rgba(0,163,255,0.13)_0,rgba(0,163,255,0)_50%,rgba(0,163,255,0)_100%)]"></div>
      
      {/* Main Content */}
      <div className="p-6 bg-[#ceeef7] rounded shadow-lg w-full max-w-md z-[1]">
        <h1 className="text-xl font-bold mb-6 text-center">Healthcare Dashboard</h1>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <InputForm register={register} errors={errors} />
          <div>
            <label className="block font-semibold text-gray-700">Upload File:</label>
            <FileUploader onFileUpload={handleFileUpload} />
            {file && <p className="text-sm text-green-500 mt-2">File uploaded: {file.name}</p>}
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default App;
